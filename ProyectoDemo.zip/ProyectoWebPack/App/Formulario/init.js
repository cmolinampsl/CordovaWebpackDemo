var angular = require('angular');

var directiva =  require('./Directives/FormularioDirectiva');

module.exports = angular.module('demo.formulario', [])
	.directive('formulario',directiva);