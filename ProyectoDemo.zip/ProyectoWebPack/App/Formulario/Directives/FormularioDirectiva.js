var formularioController = require('../Controllers/FormularioControlador');
var template = require('html-loader!../Templates/Formulario');

function FormularioDirective($compile) {
    return {
        restrict: 'A',
        scope: true,
        controller: formularioController,
        template: template
    };
}


FormularioDirective.$inject = ['$compile'];

module.exports = FormularioDirective;