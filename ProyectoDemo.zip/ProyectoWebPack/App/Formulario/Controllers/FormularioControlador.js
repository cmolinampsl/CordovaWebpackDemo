
function formularioController($scope) {
    var m7wxwcw1hko5z4;
    
    (function(d, t) {
        
        var s = d.createElement(t), options = {
            'userName':'cmolinam',
            'formHash':'m7wxwcw1hko5z4',
            'autoResize':true,
            'height':'467',
            'async':true,
            'host':'wufoo.com',
            'header':'show',
            'ssl':true};
        
        s.src = ('https:' == d.location.protocol ? 'https://' : 'http://') + 'www.wufoo.com/scripts/embed/form.js';
        s.onload = s.onreadystatechange = function() {
            var rs = this.readyState; if (rs) if (rs != 'complete') if (rs != 'loaded') return;
            try {
                m7wxwcw1hko5z4 = new WufooForm();
                m7wxwcw1hko5z4.initialize(options);
                m7wxwcw1hko5z4.display();
            } catch (e) {}
        };
        var scr = d.getElementsByTagName(t)[0], par = scr.parentNode; par.insertBefore(s, scr);
    })(document, 'script');
}

formularioController.$inject = ['$scope'];

module.exports = formularioController;