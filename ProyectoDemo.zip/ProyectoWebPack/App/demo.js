
require('./Formulario/init');

angular = require('angular');
angular.module('demo', [ 'demo.formulario']);
