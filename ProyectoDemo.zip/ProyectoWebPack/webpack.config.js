﻿'use strict';
var webpack = require('webpack'),
    path = require('path');

module.exports = {

    entry: {
        app: './App/demo.js'
    },

    output: {
        filename: 'bundle.js',
        path: '../ProyectoCordova/www/js/'
    },
    watch: true,

	/*
    modules: [
        {
            test: /\.html$/,
            exclude: /node_modules/,
            loader: 'html'
        }
    ],*/
    resolve: {
        extensions: ['.js', '.html', '.css']
    },
    devtool: 'inline-source-map'
};